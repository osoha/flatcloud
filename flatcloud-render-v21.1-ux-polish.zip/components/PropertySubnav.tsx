import Link from "next/link";

const fullSections = [
  ["prehled", "Přehled"],
  ["jednotky", "Jednotky"],
  ["najemnici", "Nájemníci"],
  ["smlouvy", "Smlouvy"],
  ["platby", "Platby"],
  ["provoz", "Provoz"],
  ["banka", "Banka a pravidla"],
  ["technicke-udaje", "Technické údaje"],
  ["nastaveni", "Nastavení"],
];
const unitSections = [["prehled","Přehled"],["jednotky","Moje jednotky"],["najemnici","Nájemníci"],["smlouvy","Smlouvy"],["platby","Platby"],["dluznici","Saldo"]];

export function PropertySubnav({ propertyId, active, unitLimited=false }: { propertyId: string; active: string; unitLimited?: boolean }) {
  const sections=unitLimited?unitSections:fullSections;
  return <nav className="section-nav v21-section-nav">{sections.map(([slug,label])=><Link className={active===slug?"active":""} key={slug} href={`/nemovitosti/${propertyId}/${slug}`}>{label}</Link>)}</nav>;
}
